// Canvas要素と2Dコンテキストの取得
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

// ポイントの初期化
let point = 0;

// プレイヤーの設定
const Player = {
    HP: 5, // プレイヤーの体力
    image: new Image(), // プレイヤーの画像
    speed: 2, // プレイヤーの移動速度
    bulletFixedInterval: 20, // 弾の発射間隔
    size: 15, // プレイヤーのサイズ
    position: { x: 50, y: 240 }, // プレイヤーの初期位置
    imageOnload: false, // 画像読み込み完了フラグ
    bulletInterval: 0, // 弾の発射間隔カウンタ
    Hitstun: 60, // ヒットスタン時間
    invincibilityTime: 0, // 無敵時間
};
Player.image.src = "./img/魔理沙right.png"; // プレイヤー画像のパス
Player.image.onload = function () {
    Player.imageOnload = true;
    checkAllImagesLoaded();
};

// プレイヤーの弾丸配列の初期化
const MyBulletArray = new Array(100).fill(null);

// 敵の設定
const enemy = {
    image: new Image(), // 敵の画像
    onload: false // 画像読み込み完了フラグ
};
enemy.image.src = "./img/youseiGreen.png"; // 敵の画像のパス
enemy.image.onload = function () {
    enemy.onload = true;
    checkAllImagesLoaded();
};

// 敵情報の初期化
let enemyInformation = {
    "enemyArray": new Array(30).fill(null), // 敵の配列
    "interbal": 120, // 敵の生成間隔カウンタ
    "fixedInterval": 10 // 敵の生成間隔
};

// 敵の弾丸配列の初期化
const enemyBulletArray = new Array(100).fill(null);

// 画像配列の作成
const imageArray = [Player.image, enemy.image];

// すべての画像の読み込みが完了したかをチェックする関数
function checkAllImagesLoaded() {
    for (const imageObj of imageArray) {
        if (!imageObj.onload) {
            return; // すべての画像がロードされていない場合は関数を終了
        }
    }
    // すべての画像がロードされた場合は、レンダリングループを開始
    window.requestAnimationFrame(update);
}

// プレイヤーの描画関数
function drawPlayer() {
    if (Player.HP <= 0) {
        return; // プレイヤーの体力が0以下の場合は描画しない
    }
    // 無敵時間中は一定間隔で点滅させる
    if (Player.invincibilityTime > 0 && (Player.invincibilityTime % 5 == 1 || Player.invincibilityTime % 5 == 2)) {
        console.log(Player.HP);
        return; // プレイヤーの体力をログに出力し、描画しない
    }
    ctx.drawImage(Player.image, Player.position.x - 15, Player.position.y - 15, Player.size * 2, Player.size * 2);
}

// キャンバスのクリア関数
function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height); // キャンバスをクリア
    ctx.fillStyle = "#14B6EC"; // 背景色を設定
    ctx.fillRect(0, 0, canvas.width, canvas.height); // 背景を描画
}

// プレイヤーの操作関数
function PlayerControl() {
    if (Player.invincibilityTime > 30) {
        Player.position.x -= 0.5; // 無敵時間中は徐々に左に移動
        return;
    }
    if (keySituation.d && Player.position.x + Player.size < canvas.width) {
        Player.position.x += Player.speed; // 右キーが押されている場合は右に移動
    } else if (keySituation.a && Player.position.x > 0) {
        Player.position.x -= Player.speed; // 左キーが押されている場合は左に移動
    }
    if (keySituation.s && Player.position.y + Player.size < canvas.height) {
        Player.position.y += Player.speed; // 下キーが押されている場合は下に移動
    } else if (keySituation.w && Player.position.y > 0) {
        Player.position.y -= Player.speed; // 上キーが押されている場合は上に移動
    }
}

// メイン更新関数
function update() {
    PlayerControl(); // プレイヤーの操作を更新
    clearCanvas(); // キャンバスをクリア

    // プレイヤーの弾丸の更新と描画
    MyBulletArray.forEach((bullet, bIndex) => {
        if (bullet) {
            ctx.beginPath();
            ctx.fillStyle = "yellow";
            ctx.arc(bullet.position.x, bullet.position.y, bullet.size, 0, Math.PI * 2);
            ctx.fill();
            bullet.position.x += bullet.speed.Vx;

            // 弾丸と敵の当たり判定
            enemyInformation.enemyArray.forEach((enemy) => {
                if (enemy) {
                    const distanceSquared = Math.pow(enemy.position.x - bullet.position.x, 2) + Math.pow(enemy.position.y - bullet.position.y, 2);
                    const collisionDistanceSquared = Math.pow(bullet.size + enemy.size, 2);
                    if (distanceSquared <= collisionDistanceSquared) {
                        enemy.HP--; // 敵の体力を減らす
                        bullet.position.x = 1000; // 弾丸を削除
                    }
                }
            });

            if (bullet && bullet.position.x > canvas.width) {
                MyBulletArray[bIndex] = null; // 画面外に出た弾丸を削除
            }
        }
    });

    // Enterキーでの弾の発射
    if (keySituation.Enter && Player.bulletInterval <= 0) {
        Player.bulletInterval = Player.bulletFixedInterval; // 弾の発射間隔の設定
        const bullet = getTemplate("MyBulletInformation");
        bullet.position.x = Player.position.x;
        bullet.position.y = Player.position.y;
        bullet.speed.Vx = 5;
        bullet.size = 15;
        const index = MyBulletArray.indexOf(null);
        if (index !== -1) {
            MyBulletArray[index] = bullet; // 空いている弾丸スロットに新しい弾を追加
        }
    }

    // 敵の生成
    if (enemyInformation.interbal <= 0) {
        enemyInformation.interbal = enemyInformation.fixedInterval; // 敵の生成間隔の設定
        const preEnemy = getTemplate("enemy");
        preEnemy.position.x = 600;
        preEnemy.position.y = 480 * Math.random();
        preEnemy.HP = 2;
        preEnemy.interval = 50;
        preEnemy.fixedInterval = 50;
        preEnemy.size = 15;
        preEnemy.speed.Vx = -(Math.random());
        preEnemy.speed.Vy = (Math.random() - 0.5) * 2 - ((preEnemy.position.y - 240) / 240);
        const index = enemyInformation.enemyArray.indexOf(null);
        if (index !== -1) {
            enemyInformation.enemyArray[index] = preEnemy; // 空いている敵スロットに新しい敵を追加
        }
    }

    // 敵の更新と描画
    enemyInformation.enemyArray.forEach((enemy, index) => {
        if (enemy) {
            ctx.drawImage(imageArray[1], enemy.position.x - enemy.size, enemy.position.y - enemy.size, enemy.size * 2, enemy.size * 2);
            enemy.position.x += enemy.speed.Vx;
            enemy.position.y += enemy.speed.Vy;
            enemy.speed.Vx -= (Math.random() - 0.4) * 0.1;
            enemy.speed.Vy += ((Math.random() - 0.5) * 0.1 - ((enemy.position.y - 240) / 240) * 0.05);
            const distanceSquared = Math.pow(enemy.position.x - Player.position.x, 2) + Math.pow(enemy.position.y - Player.position.y, 2);
            const collisionDistanceSquared = Math.pow(Player.size + enemy.size, 2);
            if (enemy.position.x > canvas.width || enemy.position.y > canvas.height || enemy.position.x < 0 || enemy.position.y < 0) {
                enemyInformation.enemyArray[index] = null; // 画面外に出た敵を削除
            } else if (distanceSquared < collisionDistanceSquared && Player.invincibilityTime <= 0) {
                Player.invincibilityTime = Player.Hitstun; // プレイヤーが敵に当たった場合の処理
                Player.HP--;
                enemyInformation.enemyArray[index] = null; // 当たった敵を削除
            } else if (enemy.HP <= 0) {
                enemyInformation.enemyArray[index] = null; // 倒された敵を削除
                point++; // ポイントを増やす
            }
        }
    });

    drawPlayer(); // プレイヤーを描画
    interval(); // インターバルの更新
    if (Player.HP <= 0) {
        finishGame(); // ゲーム終了時の処理
        return;
    }
    document.getElementById("log").innerHTML = Player.HP.toString(); // 体力をHTML要素に表示
    window.requestAnimationFrame(update); // 次のフレームを要求
}

// インターバルの更新関数
function interval() {
    Player.bulletInterval--; // 弾の発射間隔のカウントダウン
    enemyInformation.interbal--; // 敵の生成間隔のカウントダウン
    Player.invincibilityTime--; // 無敵時間のカウントダウン
}

// ゲーム終了時の処理
function finishGame() {
    document.getElementById("log").innerHTML = point.toString(); // ポイントをHTML要素に表示
}
