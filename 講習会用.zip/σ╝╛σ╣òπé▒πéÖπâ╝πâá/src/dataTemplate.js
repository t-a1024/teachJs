let number=0;
let string="";
let booleam=false;
let array=[];
let img=new Image()
const PlayerTemplate={
    "HP":number,
    "position":{"x":number,"y":number},
    "image":img,
    "size":number,
    "speed":number,
    "bulletInterval":number,
    "fixedInterval":number
}
const MyBulletInformationTemplate={
    "speed":{"Vx":number,"Vy":number},
    "position":{"x":number,"y":number},
    "size":number,
}
const enemyTemplate={
    "HP":number,
    "position":{"x":number,"y":number},
    "size":number,
    "speed":{"Vx":number,"Vy":number},
}
function getTemplate(type) {
    switch (type) {
        case "Player":
            return JSON.parse(JSON.stringify(PlayerTemplate));
        case "MyBulletInformation":
            return JSON.parse(JSON.stringify(MyBulletInformationTemplate));
        case "enemy":
            return JSON.parse(JSON.stringify(enemyTemplate));
        default:
            break;
    }
}
/* 不具合あり */